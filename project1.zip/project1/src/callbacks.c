#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>


#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "hotel.h"

hotel h;


void
on_valider_clicked                     (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3;
GtkWidget *Etoiles;
hotel h;
input1=lookup_widget(obj,"Nom_hotel");
input2=lookup_widget(obj,"adresse");
input3=lookup_widget(obj,"num_responsable");
Etoiles=lookup_widget(obj,"etoiles");
strcpy (h.nom_hotel,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.adresse,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(h.num_responsable,gtk_entry_get_text(GTK_ENTRY(input3)));
h.etoile=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Etoiles));
g_print("ajout_hotel worked");
ajout("ajout_hotel0",&h);

}


void
on_affiche_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
  fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
  fenetre_afficher=create_fenetre_afficher();
   gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_hotel(treeview1);

}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fen_log,*fen2 ;
fen_log = lookup_widget(objet,"fenetre_ajout");
fen2 = lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fen2);
fen_log = create_fenetre_ajout();
gtk_widget_show(fen_log);

}


void
on_treeview1_row_activated             (GtkTreeView     *view,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeModel *model;
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(view);


GtkTreeIter iter;
g_print("This hotel has been deleted");
model=gtk_tree_view_get_model(view);
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter,path))
  {
    gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
supprimer(str_data);
if (!gtk_tree_model_get_iter(model,&iter,path));
g_print("no deleted");
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
}



void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
supprimer ((char *)h.num_responsable);
GtkWidget *fenetre_afficher=lookup_widget(GTK_WIDGET(button),"fenetre_afficher");
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_hotel(treeview1);
gtk_widget_show(treeview1);

}

