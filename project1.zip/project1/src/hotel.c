#include "hotel.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<gtk/gtk.h>
enum
{
 HOTEL,
 ADRESSE,
 ETOILES,
 NUMERO,
 COLUMNS
};


void ajout (char hotel.bin[], hotel *h)
{
FILE *f;
f=fopen("hotel.bin","ab+");
if (f!=NULL)
{
fwrite(h,sizeof(hotel),1,f);
fclose(f);
}
}
void afficher_hotel(GtkWidget *show)
{
    hotel h;
      GtkCellRenderer *render ;
      GtkTreeViewColumn *column;
      GtkTreeIter miter;
      GtkListStore *store ;
     
      char nom_hotel[650];
      char adresse[120];
      int etoile;
      char num_responsable[30];
    store = NULL;
     
      //FILE *f ;
      store =gtk_tree_view_get_model(GTK_TREE_VIEW(show));
      if(!store){
          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("hotel",render,"text",HOTEL,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("adresse",render,"text",ADRESSE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("etoiles",render,"text",ETOILES,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("responsable",render,"text",NUMERO,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
          
          
      }
      store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING);


      FILE *f = fopen("hotel.bin","rb") ;
      if(!f) exit(-1);

      while(fread(&h,sizeof(hotel),1,f)==1)
      {
          gtk_list_store_append(store,&miter);
          
          gtk_list_store_set(store,&miter,HOTEL,h.nom_hotel,ADRESSE,h.adresse,ETOILES,h.etoile,NUMERO,h.num_responsable,-1);

      }
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(show),GTK_TREE_MODEL(store));
      g_object_unref(store);

}

void supprimer (char *num_responsable)
{
hotel h;
FILE *old;
FILE *new=NULL;

new=fopen("ajout","wb");
fclose(new);

old=fopen("hotel.bin","rb");
new=fopen("hotel_test.bin","ab");

int i=0;
while(!(feof(old)))
       {i++;
        fread(&h,1,sizeof(hotel),old);
       }
fclose(old);
old=fopen("hotel.bin","rb");

int j=0;
while(j<i-1)
      {j++;
       fread(&h,1,sizeof(hotel),old);

       if(strcmp(h.num_responsable,num_responsable))
             {
             fwrite(&h,sizeof(hotel),1,new);
             }
      }
fclose(new);
fclose(old);
remove("hotel.bin");
rename("hotel_test.bin","hotel.bin");
}



	



