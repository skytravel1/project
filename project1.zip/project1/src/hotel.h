#include <gtk/gtk.h>
typedef struct hotel hotel;
struct hotel
{char nom_hotel[20];
char adresse[20];
int  etoile;
char num_responsable[20];

} ;
void ajout (char ajout_hotel0[], hotel *h);
void afficher_hotel (GtkWidget * liste);
void supprimer (char *num_responsable);
