#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "facture.h"




void
on_valider_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
facture fa;
GtkWidget *input1,*input2,*input3 ,*input4;


input1=lookup_widget(objet_graphique,"entrycout");
input2=lookup_widget(objet_graphique,"entrylocation");
input3=lookup_widget(objet_graphique,"entryprixb");
input4=lookup_widget(objet_graphique,"entrysomme");

strcpy (fa.cout,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(fa.location,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(fa.prixb,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(fa.somme,gtk_entry_get_text(GTK_ENTRY(input4)));



ajout("facture",&fa);
}



void
on_treeview1_row_activated             (GtkTreeView     *view,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeModel *model;
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(view);


GtkTreeIter iter;
g_print("Cette facture a été supprimée");
model=gtk_tree_view_get_model(view);

if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter,path))
  {
    gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
supprimer1(str_data);
if (!gtk_tree_model_get_iter(model,&iter,path));
g_print("non supprimée");
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)

{
facture f1;
dell_user((char *)f1.cout);


GtkWidget *fenetre_afficher=lookup_widget(GTK_WIDGET(button),"fenetre_afficher");

GtkWidget *fenetre_ajout;
fenetre_ajout=lookup_widget(GTK_WIDGET(button),("fenetre_ajout"));

gtk_widget_destroy(fenetre_afficher);
fenetre_ajout=create_fenetre_ajout();
gtk_widget_show(fenetre_ajout);
GtkWidget *cout=lookup_widget(fenetre_ajout,"cout");
GtkWidget *location=lookup_widget(fenetre_ajout,"location");
GtkWidget *prixb=lookup_widget(fenetre_ajout,"prixb");
GtkWidget *somme=lookup_widget(fenetre_ajout,"somme");

gtk_entry_set_text(GTK_LABEL(cout),f1.cout);
gtk_entry_set_text(GTK_LABEL(prixb),f1.prixb);
gtk_entry_set_text(GTK_LABEL(somme),f1.somme);
}





void
on_retouraffiche_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *fen_log,*fen2 ;
fen_log = lookup_widget(objet_graphique,"fenetre_ajout");
fen2 = lookup_widget(objet_graphique,"fenetre_afficher");
gtk_widget_destroy(fen2);
fen_log = create_fenetre_ajout();
gtk_widget_show(fen_log);

}


void
on_supprimer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
facture f1;
GtkWidget *treeview1;
supprimer1(&f1.somme);
GtkWidget *fenetre_afficher=lookup_widget(GTK_WIDGET(objet_graphique),"fenetre_afficher");
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_facture(treeview1,f1);
gtk_widget_show(treeview1);
}


void
on_afficher_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
  fenetre_ajout=lookup_widget(objet_graphique,"fenetre_ajout");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher=lookup_widget(objet_graphique,"fenetre_afficher");
  fenetre_afficher=create_fenetre_afficher();
   
treeview1=lookup_widget(fenetre_afficher,"treeview1");
   gtk_widget_show(fenetre_afficher);
}

