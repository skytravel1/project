#include <gtk/gtk.h>



void
on_valider_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *view,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_retouraffiche_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
