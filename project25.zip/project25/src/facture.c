#include "facture.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<gtk/gtk.h>
enum
{
 COUT,
 LOCATION,
 PRIXB,
 SOMME,
 COLUMNS
};


void ajout (char fact[], facture *fa)
{
FILE *f;
f=fopen(fact,"ab+");
char temp[1024];
sprintf(temp," touch %s" , fact);
if (!f)  {g_print("error"); system(temp) ; f=fopen(fact,"rb");}  

fwrite(fa,sizeof(facture),1,f);
fclose(f);

}
void afficher_facture(GtkWidget *show,facture fa)
{
    
      GtkCellRenderer *render ;
      GtkTreeViewColumn *column;
      GtkTreeIter *iter;
      GtkListStore *store ;
     
      char cout[650];
      int location;
      int prixb;
      char somme[30];
    store = NULL;
     
      
      store =gtk_tree_view_get_model(GTK_TREE_VIEW(show));
      if(!store){

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("cout",render,"text",COUT,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("location",render,"text",LOCATION,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("prixb",render,"text",PRIXB,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
	  

	   render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("somme",render,"text",SOMME,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
          
          
      }
      store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING);


      FILE *f = fopen("fichier","rb") ;
      if(!f) exit(-1);

      while(fread(&fa,sizeof(facture),1,f)==1)
      {
          gtk_list_store_append(store,&iter);
          
          gtk_list_store_set(store,&iter,fa.cout,COUT,fa.location,LOCATION,fa.prixb,PRIXB,fa.somme,SOMME,-1);

      }
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(show),GTK_TREE_MODEL(store));
      g_object_unref(store);
close(f);

}

void supprimer1 (char *somme)
{
facture f1;

FILE *old;
FILE *new_=NULL;

new_=fopen("rem_facture","wb");
fclose(new_);

old=fopen("fichier","rb");
new_=fopen("rem_facture","ab");

int i=0;
while(!(feof(old)))
       {i++;
        fread(&f1,1,sizeof(facture),old);
       }
fclose(old);
old=fopen("fichier","rb");

int j=0;
while(j<i-1)
      {j++;
       fread(&f1,1,sizeof(facture),old);

       if(strcmp(f1.somme,somme))
             {
             fwrite(&f1,sizeof(facture),1,new_);
             }
      }
fclose(new_);
fclose(old);
remove("fichier");
rename("rem_facture","fichier");
}


void dell_user(char *cout)
{
facture fa;
FILE *old;
FILE *new=NULL;


new=fopen("nfactures","wb");

fclose(new);
old=fopen("fichier","rb");
new=fopen("nfactures","ab");

int i=0;
while(!(feof(old)))
{i++;
fread(&fa,1,sizeof(facture),old);}
fclose(old);
old=fopen("fichier","rb");
int j=0;
while(j<i-1)
{
j++;
fread(&fa,1,sizeof(facture),old);
g_print("%s   \n",fa.cout);
if(strcmp(fa.cout,cout))
{
fwrite(&fa,sizeof(facture),1,new);
}
}
fclose(new);
fclose(old);
remove("fichier");
rename("nfactures","fichier");
}




	



