#include <gtk/gtk.h>
typedef struct facture facture ;
struct facture
{char cout[20];
char location[20];
char prixb[20];
char somme[20];

};
void ajout (char fact[], facture *fa);
void afficher_facture (GtkWidget *liste,facture fa);
void supprimer1 (char *somme);
void dell_user(char *cout);



